=== Video Plugin ===

== Description ==

This plugin allows you to upload and manage your Playwire videos

== Installation ==

Upload the plugin to your blog, Activate it, then enter your the API key that you can get from http://www.playwire.com/users when you have an account.
